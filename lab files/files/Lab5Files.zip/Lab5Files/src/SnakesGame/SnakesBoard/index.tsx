import SnakeBoard from "./SnakeBoard";

export default SnakeBoard;
