import SnakesGame from "./SnakesGame";

export default SnakesGame;
