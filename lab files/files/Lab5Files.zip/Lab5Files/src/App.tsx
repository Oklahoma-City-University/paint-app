import SnakesGame from "./SnakesGame";

function App() {
  return <SnakesGame />;
}

export default App;
